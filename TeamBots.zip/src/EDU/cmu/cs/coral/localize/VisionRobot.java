/* This code is part of the localize package of TeamBots.
 * Copyright (c) 1999, 2000 by John Sweeney and Carnegie Mellon University
 */
package EDU.cmu.cs.coral.localize;

public interface VisionRobot {
    public double fovAngle = 30.0;
  public double depthOfView = 1.5;
}
 
